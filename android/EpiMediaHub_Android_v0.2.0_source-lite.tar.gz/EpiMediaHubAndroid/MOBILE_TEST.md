# Smartphone-Test v0.2.0

Nach dem APK-Build:

1. APK auf dem Android-Smartphone installieren.
2. EpiMediaHub öffnen. Auf einem Smartphone wird automatisch die Touch-Oberfläche aktiviert.
3. Unter `PLAYLIST` eine Xtream/M3U-Plus-URL im Format `URL # Name` einfügen oder `playlists.txt` importieren.
4. Live-TV und Filme über Kategorien öffnen und Wiedergabe testen.
5. Hoch- und Querformat testen. Im Hochformat bleibt der Player 16:9 und zeigt darunter Metadaten.
6. Unter `EINSTELLUNGEN -> Skin / Design` einen der 59 Skins auswählen.

Noch nicht fertig in v0.2.0: Serienfolgen/Staffeln, globale Suche, EPG, Favoriten/Resume, TMDb und eigener Android-Updater.
