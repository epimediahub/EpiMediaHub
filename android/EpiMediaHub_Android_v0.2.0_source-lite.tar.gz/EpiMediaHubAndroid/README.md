# EpiMediaHub Android v0.2.0

Gemeinsame Codebasis für Android-Smartphones/Tablets und Android TV / Google TV / Fire TV.

## Neu in v0.2.0
- automatische Erkennung Smartphone/Tablet vs. TV
- Touch-optimierte Smartphone-Oberfläche
- Smartphone-Startseite als 2-Spalten-Raster
- responsive Abstände, Schriftgrößen, Listen und Theme-Karten
- Portrait- und Landscape-Unterstützung auf Smartphones
- Player im Hochformat mit 16:9-Videofläche und Detailbereich
- D-Pad-/Fernbedienungsnavigation auf TV bleibt erhalten
- TV-Launcher und normaler Android-Launcher bleiben parallel aktiv

## Bereits enthalten
- Startseite mit Live-TV, Filme, Serien, Playlist, Suche und Einstellungen
- 59 EpiMediaHub-Theme-Hintergründe und Marks
- Theme-Auswahl und Persistenz
- M3U-Plus-URL-Parser mit `URL # Playlistname`
- Import einer `playlists.txt` über Android-Dateiauswahl
- mehrere Playlists und aktive Playlist
- automatische Xtream-Erkennung aus `get.php` / `player_api.php`
- Xtream-Authentifizierung
- Live-/VOD-/Serien-Kategorien und Inhaltslisten
- Media3/ExoPlayer-Wiedergabe für Live-TV und Filme
- HTTP/Cleartext-Unterstützung für typische IPTV-Server
- GitHub-Actions-Workflow für Debug-APK

## Build
Projekt in Android Studio öffnen (JDK 17+). `app` als Debug/Release bauen.

Empfohlene SDK-Konfiguration: Compile/Target SDK 35, Min SDK 23.

> Im Erstellungscontainer ist kein Android SDK installiert. Die Kotlin-Parserlogik wird lokal geprüft; die komplette APK wird anschließend über Android Studio oder GitHub Actions gebaut.

## Playlist-Format
```text
http://server:port/get.php?username=USER&password=PASS&type=m3u_plus&output=ts # Wohnzimmer
http://server2:port/get.php?username=USER2&password=PASS2&type=m3u_plus&output=ts # Familie
```

## Nächste Ausbaustufe
1. Serien: Serie -> Staffel -> Folge -> Player
2. globale Suche
3. EPG / XMLTV
4. Favoriten, Verlauf und Resume
5. TMDb-Metadaten / Poster / Cast
6. Android-Updater

Die Fan-/Auto-/Luxury-Themes sind stilisierte, eigenständige Designs und keine offizielle Marken-App.
